import React from 'react'
import { Link } from 'react-router-dom'

import DangerousHTML from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Check from '../components/check'
import Line from '../components/line'
import IconContainer from '../components/icon-container'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container">
      <Helmet>
        <title>Copy of Togthr template</title>
        <meta property="og:title" content="Copy of Togthr template" />
      </Helmet>
      <section className="home-hero">
        <video
          src="https://drive.google.com/file/d/1zAoPgEttrTsYKkcEqeAIZXJSXAg8ikJh/view?usp=sharing"
          loop
          muted
          poster="/playground_assets/870d3588c0123f6b71266833c4d1535a-1500h.jpeg"
          preload="auto"
          autoPlay
          playsInline
          className="home-video"
        ></video>
        <header data-thq="thq-navbar" className="home-navbar">
          <img
            alt="image"
            src="/playground_assets/1787109-200h.jpg"
            className="home-branding"
          />
          <div data-thq="thq-burger-menu" className="home-burger-menu">
            <div className="home-hamburger">
              <img
                alt="image"
                src="/playground_assets/hamburger.svg"
                className="home-icon"
              />
            </div>
          </div>
          <div data-thq="thq-mobile-menu" className="home-mobile-menu">
            <div
              data-thq="thq-mobile-menu-nav"
              data-role="Nav"
              className="home-nav"
            >
              <div className="home-container1">
                <img
                  alt="image"
                  src="https://play.teleporthq.io/static/svg/placeholders/no-image.svg"
                  className="home-image"
                />
                <div data-thq="thq-close-menu" className="home-menu-close">
                  <svg viewBox="0 0 1024 1024" className="home-icon01">
                    <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                  </svg>
                </div>
              </div>
              <nav
                data-thq="thq-mobile-menu-nav-links"
                data-role="Nav"
                className="home-nav1"
              >
                <span className="home-text">About</span>
                <span className="home-text001">Features</span>
                <span className="home-text002">Pricing</span>
                <span className="home-text003">Team</span>
                <span className="home-text004">Blog</span>
              </nav>
              <div className="home-container2">
                <button className="home-login button">Login</button>
                <button className="button">Register</button>
              </div>
            </div>
            <div className="home-icon-group">
              <svg viewBox="0 0 950.8571428571428 1024" className="home-icon03">
                <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
              </svg>
              <svg viewBox="0 0 877.7142857142857 1024" className="home-icon05">
                <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
              </svg>
              <svg viewBox="0 0 602.2582857142856 1024" className="home-icon07">
                <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
              </svg>
            </div>
          </div>
        </header>
        <div className="home-hero-content">
          <div className="home-header-container">
            <div className="home-header">
              <h1 className="home-heading">WELCOME TO SRM MESS PORTAL</h1>
            </div>
            <p className="home-caption">
              &quot; Food that brings tears and makes you remember your home.
              &quot;
            </p>
          </div>
          <button className="button home-button">
            <a
              href="https://www.srmist.edu.in/"
              target="_blank"
              rel="noreferrer noopener"
              className="home-link"
            >
              Know more about us.....
            </a>
          </button>
        </div>
      </section>
      <section className="home-note">
        <h2 className="home-caption01">
          The students staying at SRM hostels are provided with healthy and
          sumptuous food options at highly subsidized rates. They can choose to
          have North Indian or South Indian menu in the dining halls that are
          co-located. For the benefit of our international students, the hostels
          also offer a multi-cuisine dining facility providing Thai, Chinese and
          continental food.
        </h2>
      </section>
      <section className="home-statistics">
        <div className="home-content">
          <div className="home-stat">
            <h3 className="home-header01">5+</h3>
            <span className="home-caption02">Available mess</span>
          </div>
          <div className="home-stat1">
            <h3 className="home-header02">11,500+</h3>
            <span className="home-caption03">
              <span>
                Student
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
              <br></br>
              <span>mess holding capacity</span>
            </span>
          </div>
          <div className="home-stat2">
            <h3 className="home-header03">21+</h3>
            <span className="home-caption04">
              <span className="home-text008">Hostels</span>
              <br className="home-text009"></br>
              <br></br>
            </span>
          </div>
        </div>
      </section>
      <section className="home-slider">
        <div className="home-header04">
          <h2 className="home-heading01">You get what you Desire.....</h2>
        </div>
        <div className="home-selector">
          <div className="home-slide-titles">
            <div className="slide-title">
              <span>PF Mess</span>
            </div>
            <div className="slide-title slide-title-active">
              <span>Sannasi Mess</span>
            </div>
            <div className="slide-title">
              <span>Agasthiyar Mess</span>
            </div>
            <div className="slide-title">
              <span>D-Mess</span>
            </div>
          </div>
        </div>
      </section>
      <section className="home-slides">
        <div className="home-slider1 slider blaze-slider">
          <div className="home-slider-container blaze-container">
            <div className="home-slider-track-container blaze-track-container">
              <div className="home-slider-track blaze-track">
                <div data-role="current-banner" className="banner">
                  <img
                    alt="image"
                    src="/playground_assets/img-20230426-wa0009%20%5B1%5D-400h.jpg"
                    className="home-image01"
                  />
                  <div className="home-content01">
                    <div className="home-header05">
                      <h3 className="home-heading02">PF Mess</h3>
                      <p className="home-caption05">
                        <span>Location: Near PF Hostel</span>
                        <br></br>
                        <span>Time: 7:00am - 9:00pm</span>
                        <br></br>
                      </p>
                    </div>
                    <div className="home-more">
                      <a
                        href="https://www.srmist.edu.in/srm-hostels/hostel-for-men/"
                        target="_blank"
                        rel="noreferrer noopener"
                        className="home-caption06"
                      >
                        Read More
                      </a>
                      <svg viewBox="0 0 1024 1024" className="home-icon09">
                        <path d="M298.667 341.333h323.669l-353.835 353.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l353.835-353.835v323.669c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-426.667c0-5.803-1.152-11.307-3.243-16.341s-5.163-9.728-9.216-13.781c-0.043-0.043-0.043-0.043-0.085-0.085-3.925-3.925-8.619-7.083-13.781-9.216-5.035-2.091-10.539-3.243-16.341-3.243h-426.667c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                      </svg>
                    </div>
                  </div>
                </div>
                <div data-role="current-banner" className="banner">
                  <img
                    alt="image"
                    src="/playground_assets/img20230426194725%20%5B1%5D-500h.jpg"
                    className="home-image02"
                  />
                  <div className="home-content02">
                    <div className="home-header06">
                      <h3 className="home-heading03">Sannasi Mess</h3>
                      <p className="home-caption07">
                        <span className="home-text019">
                          Location: Sannasi Hostel
                        </span>
                        <br></br>
                        <span>Time: 7:00am - 9:15pm</span>
                        <br></br>
                      </p>
                    </div>
                    <div className="home-more1">
                      <a
                        href="https://www.srmist.edu.in/srm-hostels/hostel-for-men/"
                        target="_blank"
                        rel="noreferrer noopener"
                        className="home-caption08"
                      >
                        Read More
                      </a>
                      <svg viewBox="0 0 1024 1024" className="home-icon11">
                        <path d="M298.667 341.333h323.669l-353.835 353.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l353.835-353.835v323.669c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-426.667c0-5.803-1.152-11.307-3.243-16.341s-5.163-9.728-9.216-13.781c-0.043-0.043-0.043-0.043-0.085-0.085-3.925-3.925-8.619-7.083-13.781-9.216-5.035-2.091-10.539-3.243-16.341-3.243h-426.667c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                      </svg>
                    </div>
                  </div>
                </div>
                <div data-role="current-banner" className="banner">
                  <img
                    alt="image"
                    src="/playground_assets/img20230426194057%20%5B1%5D-400h.jpg"
                    className="home-image03"
                  />
                  <div className="home-content03">
                    <div className="home-header07">
                      <h3 className="home-heading04">Agasthiyar Mess</h3>
                      <p className="home-caption09">
                        <span className="home-text023">
                          Location: Below Agasthiyar Mess
                        </span>
                        <br></br>
                        <span>Time: 7:00am - 9:15pm</span>
                        <br></br>
                      </p>
                    </div>
                    <div className="home-more2">
                      <a
                        href="https://www.srmist.edu.in/srm-hostels/hostel-for-men/"
                        target="_blank"
                        rel="noreferrer noopener"
                        className="home-caption10"
                      >
                        Read More
                      </a>
                      <svg viewBox="0 0 1024 1024" className="home-icon13">
                        <path d="M298.667 341.333h323.669l-353.835 353.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l353.835-353.835v323.669c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-426.667c0-5.803-1.152-11.307-3.243-16.341s-5.163-9.728-9.216-13.781c-0.043-0.043-0.043-0.043-0.085-0.085-3.925-3.925-8.619-7.083-13.781-9.216-5.035-2.091-10.539-3.243-16.341-3.243h-426.667c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                      </svg>
                    </div>
                  </div>
                </div>
                <div data-role="current-banner" className="banner">
                  <img
                    alt="image"
                    src="/playground_assets/img20230426194332%20%5B3%5D-400h.jpg"
                    className="home-image04"
                  />
                  <div className="home-content04">
                    <div className="home-header08">
                      <h3 className="home-heading05">D-Mess</h3>
                      <p className="home-caption11">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                        <span
                          dangerouslySetInnerHTML={{
                            __html: ' ',
                          }}
                        />
                      </p>
                    </div>
                    <div className="home-more3">
                      <a
                        href="https://www.srmist.edu.in/srm-hostels/hostel-for-men/"
                        target="_blank"
                        rel="noreferrer noopener"
                        className="home-caption12"
                      >
                        Read More
                      </a>
                      <svg viewBox="0 0 1024 1024" className="home-icon15">
                        <path d="M298.667 341.333h323.669l-353.835 353.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l353.835-353.835v323.669c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-426.667c0-5.803-1.152-11.307-3.243-16.341s-5.163-9.728-9.216-13.781c-0.043-0.043-0.043-0.043-0.085-0.085-3.925-3.925-8.619-7.083-13.781-9.216-5.035-2.091-10.539-3.243-16.341-3.243h-426.667c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="home-controls">
              <button
                data-role="previous-banner-button"
                className="home-previous blaze-prev button"
              >
                <svg viewBox="0 0 1024 1024" className="home-icon17">
                  <path d="M542.165 780.501l-225.835-225.835h494.336c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-494.336l225.835-225.835c16.683-16.683 16.683-43.691 0-60.331s-43.691-16.683-60.331 0l-298.667 298.667c-4.096 4.096-7.168 8.789-9.259 13.824-2.176 5.205-3.243 10.795-3.243 16.341 0 10.923 4.181 21.845 12.501 30.165l298.667 298.667c16.683 16.683 43.691 16.683 60.331 0s16.683-43.691 0-60.331z"></path>
                </svg>
              </button>
              <button
                data-role="next-banner-button"
                className="home-next blaze-next button"
              >
                <svg viewBox="0 0 1024 1024" className="home-icon19">
                  <path d="M481.835 243.499l225.835 225.835h-494.336c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667h494.336l-225.835 225.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l298.667-298.667c3.925-3.925 7.083-8.619 9.259-13.824 4.309-10.453 4.309-22.229 0-32.683-2.091-5.035-5.163-9.728-9.259-13.824l-298.667-298.667c-16.683-16.683-43.691-16.683-60.331 0s-16.683 43.691 0 60.331z"></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div>
          <DangerousHTML
            html={`<script>
const el = document.querySelector('.blaze-slider')

new BlazeSlider(el, {
  all: {
    slidesToShow: 3,
    slideGap: '80px',
    loop: true,
    enableAutoplay: true,
  },
})
</script>`}
          ></DangerousHTML>
        </div>
      </section>
      <section className="home-objectives">
        <div className="home-content05">
          <span className="home-text027">Objectives</span>
          <div className="home-objectives-list">
            <div className="objective">
              <h3 className="home-text028">Learn</h3>
              <p className="home-text029">
                <span className="home-text030">
                  &quot;The capacity to learn is a gift; the ability to learn is
                  a skill; the willingness to learn is a choice.&quot; - Brian
                  Herbert
                </span>
                <span>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
              </p>
            </div>
            <div className="objective home-objective1">
              <h3 className="home-text032">Leap</h3>
              <p className="home-text033">
                <span className="home-text034">
                  &quot;Do not wait; the time will never be &apos;just
                  right.&apos; Start where you stand, and work with whatever
                  tools you may have at your command, and better tools will be
                  found as you go along.&quot; - George Herbert
                </span>
                <span>
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
              </p>
            </div>
            <div className="objective home-objective2">
              <h3 className="home-text036">Lead</h3>
              <p className="home-text037">
                &quot;The function of leadership is to produce more leaders, not
                more followers.&quot; - Ralph Nader
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="home-growth">
        <div className="home-content06">
          <div className="home-header09">
            <div className="home-header10">
              <h2 className="home-heading06">
                <span>Vision Executor&quot;</span>
                <br></br>
              </h2>
            </div>
            <p className="home-caption13">Debasish Ray</p>
            <p className="home-caption14">
              <span>
                Hello, connections, Debasish Ray, a computer geek would like to
                take your O(1) time.
              </span>
              <br></br>
              <span>
                Explored various fields including BlockChain Development,
                Front-End Development, Back-End Development, and Android
                Development.
              </span>
              <br></br>
              <span>
                I have come across many programming languages like- Python , C++
                , JAVA , C and has core strength in Python and C++ language.
              </span>
              <br></br>
            </p>
          </div>
          <div className="home-testimonial">
            <div className="home-content07">
              <span className="home-text046">What he says</span>
              <p className="home-text047">“Never reveal your true self.”</p>
            </div>
            <div className="home-information">
              <div className="home-author">
                <img
                  alt="image"
                  src="/playground_assets/img_20230426_202525%20%5B1%5D-1400w.jpg"
                  className="home-icon21"
                />
                <a
                  href="https://www.linkedin.com/in/debasishray1/"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="home-name"
                >
                  Debasish Ray | LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="home-images">
          <div className="home-square"></div>
          <img
            alt="image"
            src="/playground_assets/img_20230426_202525%20%5B1%5D-1400w.jpg"
            className="home-image05"
          />
        </div>
      </section>
      <section className="home-experience">
        <div className="home-images1">
          <div className="home-square1"></div>
          <img
            alt="image"
            src="/playground_assets/utkarsh08_rs__297866612_414601360647357_7719986308620023613_n-1400w.jpg"
            className="home-image06"
          />
        </div>
        <div className="home-content08">
          <div className="home-header11">
            <div className="home-header-container1">
              <div className="home-header12">
                <h2 className="home-heading07">&quot;Vision Quantifier</h2>
              </div>
              <p className="home-caption15">Utkarsh Raj Sinha</p>
            </div>
            <div className="home-checkmarks">
              <div className="home-check">
                <span className="home-text048">
                  I am a Computer Engineering student who&apos;s currently based
                  out of Chennai, Tamil Nadu, India. A quick learner and a hard
                  working individual striving to do better.
                </span>
              </div>
              <div className="home-check1"></div>
              <div className="home-check2"></div>
            </div>
          </div>
          <div className="home-testimonial1">
            <div className="home-content09">
              <span className="home-text049">WHAT HE BELIEVES</span>
              <p className="home-text050">
                “Life is not something we fight, the fight itself is life
                against our actions and it&apos;s repulsions. ”
              </p>
            </div>
            <div className="home-information1">
              <div className="home-author1">
                <img
                  alt="image"
                  src="/playground_assets/utkarsh08_rs__297866612_414601360647357_7719986308620023613_n-1400w.jpg"
                  className="home-icon22"
                />
                <a
                  href="https://www.linkedin.com/in/utkarsh-raj-sinha-542b67233/"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="home-name1"
                >
                  Utkarsh Raj Sinha | LinkedIn
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="home-create">
        <div className="home-content10">
          <div className="home-header13">
            <h2 className="home-heading08">
              <span className="home-text051">
                Have a Glance of Today&apos;s Menu
              </span>
              <br></br>
              <br></br>
              <br></br>
              <br></br>
              <br></br>
            </h2>
          </div>
          <button className="home-button1 button">
            <span>Get Started -&gt;</span>
          </button>
        </div>
      </section>
      <section className="home-comparision">
        <div className="home-header-container2">
          <div className="home-header14">
            <h2 className="home-heading09">More to go.....</h2>
          </div>
          <p className="home-caption16">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do
            eiusmod.
          </p>
        </div>
        <div className="home-table">
          <div className="home-row">
            <div className="home-headers">
              <span className="home-text058">Placeholder</span>
            </div>
            <div className="home-plans">
              <div className="home-row01">
                <span className="home-text059">Breakfast</span>
                <span className="home-text060">Lunch</span>
                <span className="home-text061">Dinner</span>
              </div>
            </div>
          </div>
          <div className="home-row02">
            <div className="home-headers1">
              <span className="home-text062">Sannasi Mess</span>
            </div>
            <div className="home-plans1">
              <div className="home-row03">
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Check></Check>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row04">
            <div className="home-headers2">
              <span className="home-text063">Agasthiyar Mess</span>
            </div>
            <div className="home-plans2">
              <div className="home-row05">
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row06">
            <div className="home-headers3">
              <span className="home-text064">D-Mess</span>
            </div>
            <div className="home-plans3">
              <div className="home-row07">
                <div className="value">
                  <span className="home-text065">Custom</span>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row08">
            <div className="home-headers4">
              <span className="home-text066">M-Block Mess</span>
            </div>
            <div className="home-plans4">
              <div className="home-row09">
                <div className="value">
                  <span className="home-text067">Unlimited</span>
                </div>
                <div className="value">
                  <span className="home-text068">Limited</span>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row10">
            <div className="home-headers5">
              <span className="home-text069">Meenakshi Mess</span>
            </div>
            <div className="home-plans5">
              <div className="home-row11">
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
                <div className="value">
                  <span className="home-text070">Limited</span>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row12">
            <div className="home-headers6">
              <span className="home-text071">PF Mess</span>
            </div>
            <div className="home-plans6">
              <div className="home-row13">
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <Check></Check>
                </div>
              </div>
            </div>
          </div>
          <div className="home-row14">
            <div className="home-headers7">
              <span className="home-text072">Medical-Block Mess</span>
            </div>
            <div className="home-plans7">
              <div className="home-row15">
                <div className="value">
                  <Check></Check>
                </div>
                <div className="value">
                  <span className="home-text073">Limited</span>
                </div>
                <div className="value">
                  <Line></Line>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="home-data">
        <div className="home-header-container3">
          <div className="home-header15">
            <div className="home-row16">
              <h2 className="home-heading10">
                &apos;&apos;&apos; Eat all you can take &amp; take all you can 
                    eat... &apos;&apos;&apos;
              </h2>
            </div>
          </div>
        </div>
        <div className="home-content11">
          <div className="home-image07">
            <img
              alt="image"
              src="/playground_assets/housing-1400w.png"
              className="home-image08"
            />
          </div>
          <div className="home-accordion">
            <div data-role="accordion-container" className="accordion">
              <div>
                <h3 className="home-header16">Management</h3>
                <p data-role="accordion-content" className="accordion-content">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
              </div>
              <IconContainer rootClassName="icon-container-root-class-name"></IconContainer>
            </div>
            <div data-role="accordion-container" className="accordion">
              <div>
                <h3 className="home-header17">Integrations</h3>
                <p data-role="accordion-content" className="accordion-content">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
              </div>
              <IconContainer rootClassName="icon-container-root-class-name1"></IconContainer>
            </div>
            <div data-role="accordion-container" className="accordion">
              <div>
                <h3 className="home-header18">Student Solutions</h3>
                <p data-role="accordion-content" className="accordion-content">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
              </div>
              <IconContainer rootClassName="icon-container-root-class-name2"></IconContainer>
            </div>
            <div data-role="accordion-container" className="accordion">
              <div>
                <h3 className="home-header19">Transport Networks</h3>
                <p data-role="accordion-content" className="accordion-content">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
              </div>
              <IconContainer rootClassName="icon-container-root-class-name3"></IconContainer>
            </div>
            <div>
              <DangerousHTML
                html={`<script>
 /*
  Accordion - Code Embed
  */
  const accordionContainers = document.querySelectorAll('[data-role="accordion-container"]'); // All accordion containers
  const accordionContents = document.querySelectorAll('[data-role="accordion-content"]'); // All accordion content
  const accordionIconsClosed = document.querySelectorAll('[data-role="accordion-icon-closed"]'); // All accordion closed icons
  const accordionIconsOpen = document.querySelectorAll('[data-role="accordion-icon-open"]'); // All accordion open icons

  accordionContents.forEach((accordionContent) => {
      accordionContent.style.display = "none"; //Hides all accordion contents
  });

  accordionIconsClosed.forEach((icon) => {
    icon.style.display = "flex"
  })

  accordionIconsOpen.forEach((icon) => {
    icon.style.display = "none"
  })

  accordionContainers.forEach((accordionContainer, index) => {
      accordionContainer.addEventListener("click", () => {
          if (accordionContents[index].style.display === "flex") {
              // If the accordion is already open, close it
              accordionContents[index].style.display = "none";
              accordionIconsClosed[index].style.display = "flex";
              accordionIconsOpen[index].style.display = "none"
          } else {
              // If the accordion is closed, open it
              accordionContents.forEach((accordionContent) => {
                  accordionContent.style.display = "none"; //Hides all accordion contents
              });

              accordionIconsClosed.forEach((accordionIcon) => {
                  accordionIcon.style.display = "flex"; // Resets all icon transforms to 0deg (default)
              });

              accordionIconsOpen.forEach((accordionIcon) => {
                accordionIcon.style.display = "none";
              })
              
              accordionContents[index].style.display = "flex"; // Shows accordion content
              accordionIconsClosed[index].style.display = "none"; // Rotates accordion icon 180deg
              accordionIconsOpen[index].style.display = "flex";
          }
      });
  });
</script>
`}
              ></DangerousHTML>
            </div>
          </div>
        </div>
      </section>
      <section className="home-customer">
        <div className="home-header20">
          <h2 className="home-heading11">
            <span className="home-text074">
              Student validation is an essential phase of the
            </span>
            <span>
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </span>
            <span className="home-text076">improvement in mess system.</span>
            <br className="home-text077"></br>
          </h2>
        </div>
        <div className="home-quotes">
          <div className="home-quote">
            <p className="home-quote1">
              One of the best hostels I’ve ever stayed at. I came here when I
              was in first year at SRM and now I’ve graduated my final year. It
              was totally worth it. The food is so good and the food tastes like
              heaven and it’s completely a home made food too. The owner
              Venugopal sir is a very good man and kind hearted man. He is
              always sweet and talks nice to us. One of the cheapest and best
              hostels ever to exist. I would really suggest you to stay here if
              you ever need a place to stay near potheri 💯👌🏾
            </p>
            <div className="home-author2">
              <span className="home-name2">Danish Raja</span>
              <span className="home-location">Estancia</span>
            </div>
          </div>
          <div className="home-quote2">
            <p className="home-quote3">
              The hostel is maintained well with good connectivity of everything
              around the hostel like taxis, groceries, medicines etc. The wifi
              connectivity is also good which is good enough for your college
              work or browsing movies. The owner has helping nature, for any
              help just ask him, and he also speaks Hindi. The food is homely
              and good. The rooms are clean and also the rooms get cleaned
              alternate days.
            </p>
            <div className="home-author3">
              <span className="home-name3">Debasish Ray</span>
              <span className="home-location1">Manoranjitham Hostel</span>
            </div>
          </div>
          <div className="home-quote4">
            <p className="home-quote5">
              <span>I have been there for couple of months.</span>
              <br className="home-text079"></br>
              <br></br>
              <span>
                Rooms are clean and well maintained. Food is hygienic and tasty
                when compared to PG&apos;s around SRM University. If ur looking
                for better stay aroud SRM University with homely food then go
                for SMS hostel all the way.
              </span>
            </p>
            <div className="home-author4">
              <span className="home-name4">Siddhantha Beti</span>
              <span className="home-location2">Nelson Mandela Hostel</span>
            </div>
          </div>
          <div className="home-quote6">
            <p className="home-quote7">
              <span>My brother is staying in sms hostel potheri</span>
              <br></br>
              <span>
                He is always complaining that they are giving always leftover
                fermented foods...
              </span>
              <br></br>
              <span>And always sambar and dhal daily....</span>
              <br></br>
              <span>Hostel is okay</span>
              <br></br>
              <span>But food there is worst..</span>
              <br className="home-text091"></br>
              <br></br>
              <span>I&apos;m urged my brother to change the hostel..</span>
            </p>
            <div className="home-author5">
              <span className="home-name5">Utkarsh Raj Sinha</span>
              <span className="home-location3">Mullai Hostel</span>
            </div>
          </div>
        </div>
        <div className="home-controls1">
          <button className="home-previous1 button">
            <svg viewBox="0 0 1024 1024" className="home-icon23">
              <path d="M542.165 780.501l-225.835-225.835h494.336c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-494.336l225.835-225.835c16.683-16.683 16.683-43.691 0-60.331s-43.691-16.683-60.331 0l-298.667 298.667c-4.096 4.096-7.168 8.789-9.259 13.824-2.176 5.205-3.243 10.795-3.243 16.341 0 10.923 4.181 21.845 12.501 30.165l298.667 298.667c16.683 16.683 43.691 16.683 60.331 0s16.683-43.691 0-60.331z"></path>
            </svg>
          </button>
          <button className="home-next1 button">
            <svg viewBox="0 0 1024 1024" className="home-icon25">
              <path d="M481.835 243.499l225.835 225.835h-494.336c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667h494.336l-225.835 225.835c-16.683 16.683-16.683 43.691 0 60.331s43.691 16.683 60.331 0l298.667-298.667c3.925-3.925 7.083-8.619 9.259-13.824 4.309-10.453 4.309-22.229 0-32.683-2.091-5.035-5.163-9.728-9.259-13.824l-298.667-298.667c-16.683-16.683-43.691-16.683-60.331 0s-16.683 43.691 0 60.331z"></path>
            </svg>
          </button>
          <button className="button home-button2">
            <a
              href="https://youtu.be/BBJa32lCaaY"
              target="_blank"
              rel="noreferrer noopener"
              className="home-link1"
            >
              <span>View all reviews</span>
              <br></br>
            </a>
          </button>
        </div>
      </section>
      <section className="home-faq">
        <div className="home-header21">
          <h2 className="home-heading12">Suggestions&apos; Space</h2>
        </div>
        <div className="home-content20">
          <div className="home-column">
            <div className="home-element04">
              <h3 className="home-header22">
                Lorem ipsum dolor sit ametetur elit?
              </h3>
              <p className="home-content21">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </p>
            </div>
            <div className="home-element05">
              <h3 className="home-header23">
                Excepteur sint occaecat cupidatat non sunt in culpa qui officia
                deserunt mollit anim id est laborum?
              </h3>
              <p className="home-content22">
                Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
                quae ab illo inventore veritatis et quasi architecto beatae
                vitae dicta sunt explicabo.
              </p>
            </div>
            <div className="home-element06">
              <h3 className="home-header24">
                Tempor incididunt ut labore et dolore magna aliquat enim ad
                minim?
              </h3>
              <p className="home-content23">
                Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                commodo consequat. Duis aute irure dolor in reprehenderit in
                voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                Excepteur sint occaecat cupidatat non proident, sunt in culpa
                qui officia deserunt mollit anim id est laborum.
              </p>
            </div>
          </div>
          <div className="home-column1">
            <div className="home-element07">
              <h3 className="home-header25">
                Tempor incididunt ut labore et dolore magna aliquat enim ad
                minim?
              </h3>
              <p className="home-content24">
                Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                commodo consequat. Duis aute irure dolor in reprehenderit in
                voluptate velit esse cillum dolore eu fugiat nulla pariatur.
                Excepteur sint occaecat cupidatat non proident, sunt in culpa
                qui officia deserunt mollit anim id est laborum.
              </p>
            </div>
            <div className="home-element08">
              <h3 className="home-header26">
                Lorem ipsum dolor sit ametetur elit?
              </h3>
              <p className="home-content25">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </p>
            </div>
            <div className="home-element09">
              <h3 className="home-header27">Incididunt ut labore et dolore?</h3>
              <p className="home-content26">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </p>
            </div>
          </div>
        </div>
        <button className="button home-button3">
          <a
            href="https://forms.gle/8KpE6BSR2uzkWviX9"
            target="_blank"
            rel="noreferrer noopener"
            className="home-link2"
          >
            Suggest your opinion -&gt;
          </a>
        </button>
      </section>
      <div className="home-footer">
        <div className="home-content27">
          <div className="home-main">
            <div className="home-branding1">
              <img
                alt="image"
                src="/playground_assets/1787109-200h.jpg"
                className="home-image09"
              />
              <span className="home-text096">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
                <span
                  dangerouslySetInnerHTML={{
                    __html: ' ',
                  }}
                />
              </span>
            </div>
            <div className="home-links">
              <div className="home-column2">
                <span className="home-header28">Company</span>
                <div className="home-list">
                  <Link to="/" className="home-navlink">
                    About
                  </Link>
                  <Link to="/" className="home-navlink01">
                    Services
                  </Link>
                  <Link to="/" className="home-navlink02">
                    How
                  </Link>
                  <Link to="/" className="home-navlink03">
                    <span className="home-text097">Why</span>
                    <br></br>
                  </Link>
                </div>
              </div>
              <div className="home-column3">
                <span className="home-header29">Extern</span>
                <div className="home-list1">
                  <Link to="/" className="home-navlink04">
                    News
                  </Link>
                  <Link to="/" className="home-navlink05">
                    Articles
                  </Link>
                  <Link to="/" className="home-navlink06">
                    Blog
                  </Link>
                  <Link to="/" className="home-navlink07">
                    Privacy
                  </Link>
                  <Link to="/" className="home-navlink08">
                    Terms
                  </Link>
                  <Link to="/" className="home-navlink09">
                    Legal
                  </Link>
                  <Link to="/" className="home-navlink10">
                    Press
                  </Link>
                </div>
              </div>
              <div className="home-column4">
                <span className="home-header30">Social</span>
                <div className="home-list2">
                  <Link to="/" className="home-navlink11">
                    LinkedIn
                  </Link>
                  <Link to="/" className="home-navlink12">
                    Twitter
                  </Link>
                  <Link to="/" className="home-navlink13">
                    Instagram
                  </Link>
                  <Link to="/" className="home-navlink14">
                    Facebook
                  </Link>
                  <Link to="/" className="home-navlink15">
                    TikTok
                  </Link>
                </div>
              </div>
            </div>
          </div>
          <div className="home-bottom">
            <span className="home-text099">
              © 2022 togthr - All rights reserved
            </span>
            <button data-role="scroll-top" className="home-button4 button">
              <img
                alt="image"
                src="/playground_assets/arrow.svg"
                className="home-image10"
              />
            </button>
          </div>
        </div>
      </div>
      <div>
        <DangerousHTML
          html={`<script>
document.addEventListener("DOMContentLoaded", function() {
  // get the element with the "scroll-top" data-role
  const scrollTopBtn = document.querySelector('[data-role="scroll-top"]');

  // when the element is clicked
  scrollTopBtn.addEventListener("click", function() {
    // smoothly scroll to the top of the page
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  });
});
</script>
`}
        ></DangerousHTML>
      </div>
    </div>
  )
}

export default Home
